-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 28, 2021 at 10:52 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.4.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inventory`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `product_price` varchar(100) NOT NULL,
  `product_image` varchar(100) NOT NULL,
  `qty` varchar(100) NOT NULL,
  `total_price` varchar(100) NOT NULL,
  `product_code` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `item_list`
--

CREATE TABLE `item_list` (
  `id` int(11) NOT NULL,
  `product` varchar(50) NOT NULL,
  `stock` varchar(50) NOT NULL,
  `price` varchar(50) NOT NULL,
  `category` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `item_list`
--

INSERT INTO `item_list` (`id`, `product`, `stock`, `price`, `category`) VALUES
(1, 'Bread', '20', '50', 'Fruits/Vegetables'),
(2, 'Bell pepper', '20', '20', 'Fruits/Vegetables'),
(3, 'Brocoli', '20', '10', 'Fruits/Vegetables'),
(4, 'Cabbage', '50', '100', 'Fruits/Vegetables'),
(5, 'Chili', '75', '10', 'Fruits/Vegetables'),
(6, 'Coke', '75', '25', 'Beverages'),
(7, 'Colgate', '120', '50', 'Condiments/Spices'),
(8, 'Eggplant', '100', '20', 'Fruits/Vegetables'),
(9, 'Mango', '25', '50', 'Fruits/Vegetables'),
(10, 'Meat', '150', '20', 'Meat'),
(11, 'Nova', '100', '20', 'Snacks'),
(12, 'OIshi', '6', '20', 'Snacks'),
(13, 'Oishi Cracklings', '15', '50', 'Snacks'),
(14, 'Onions', '50', '25', 'Fruits/Vegetables'),
(15, 'Crispy Patata', '12', '100', 'Snacks'),
(16, 'Pepsi', '65', '35', 'Beverages'),
(17, 'Petchay', '60', '30', 'Fruits/Vegetables'),
(18, 'Piattos', '20', '45', 'Snacks'),
(19, 'Royal', '125', '50', 'Beverages'),
(20, 'Safeguard', '110', '60', 'Condiments/Spices'),
(21, 'Vcut', '15', '20', 'Snacks'),
(22, 'Watermelon', '130', '20', 'Fruits/Vegetables');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `pmode` varchar(100) NOT NULL,
  `products` varchar(100) NOT NULL,
  `amount_paid` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `name`, `email`, `phone`, `address`, `pmode`, `products`, `amount_paid`) VALUES
(1, 'james', 'roxasjameslago22@gamil.com', '09975849996', 'cuenca batangas', 'cod', 'Bread(5)', '100');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `image` varchar(50) NOT NULL,
  `price` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `name`, `image`, `price`) VALUES
(1, 'Bread', 'breadResize.JPG', '23.75'),
(2, 'Apple', 'appleResize.JPG', '20.00'),
(3, 'Orange', 'orangeResize.JPG', '50.00'),
(4, 'Banana', '', '30.00'),
(5, 'Chicken', '', '109.09'),
(6, 'Milk', '', '270.79');

-- --------------------------------------------------------

--
-- Table structure for table `product1`
--

CREATE TABLE `product1` (
  `id` int(11) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `product_price` varchar(100) NOT NULL,
  `product_qty` varchar(100) NOT NULL,
  `product_image` varchar(100) NOT NULL,
  `product_code` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product1`
--

INSERT INTO `product1` (`id`, `product_name`, `product_price`, `product_qty`, `product_image`, `product_code`) VALUES
(1, 'Bread', '20', '1', 'breadResize.JPG', '001'),
(2, 'Bell pepper', '20', '1', 'bellpepper.JPEG', '002'),
(3, 'Brocoli', '20', '1', 'brocoli.JPEG', '003'),
(4, 'Cabbage', '50', '1', 'cabbage.JPEG', '004'),
(5, 'Chili', '75', '1', 'chili.JPEG', '005'),
(6, 'Coke ', '75', '1', 'coke.jpeg', '006'),
(7, 'Colgate', '120', '1', 'colgate.jpeg', '007'),
(8, 'Eggplant', '100', '1', 'eggplant.jpeg', '008'),
(9, 'Mango', '25', '1', 'mango.jpeg', '009'),
(10, 'Meat', '150', '1', 'meat.jpeg', '010'),
(11, 'Nova', '100', '1', 'nova.jpeg', '011'),
(12, 'Oishi', '6', '1', 'oishi.jpeg', '012'),
(13, 'Oishi Cracklings', '15', '1', 'oishicrackling.jpeg', '013'),
(14, 'Onions', '50', '1', 'onions.jpeg', '014'),
(15, 'Crispy Patata', '12', '1', 'patata.jpeg', '015'),
(16, 'Pepsi ', '65', '1', 'pepsi.jpeg', '016'),
(17, 'Petchay', '60', '1', 'petchay.jpeg', '017'),
(18, 'Piattos', '20', '1', 'piatos.jpeg', '018'),
(19, 'Royal', '125', '1', 'royal.jpeg', '019'),
(20, 'Safeguard', '110', '1', 'safeguard.jpeg', '020'),
(21, 'Vcut', '15', '1', 'vcut.jpeg', '021'),
(22, 'Watermelon', '130', '1', 'watermelon.jpeg', '022');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `name` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `contact` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `gender` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`name`, `password`, `contact`, `email`, `gender`) VALUES
('james ', '00000', '09975849996', 'roxasjamesmaynard@yahoo.com', 'male');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `item_list`
--
ALTER TABLE `item_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product1`
--
ALTER TABLE `product1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `item_list`
--
ALTER TABLE `item_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `product1`
--
ALTER TABLE `product1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
